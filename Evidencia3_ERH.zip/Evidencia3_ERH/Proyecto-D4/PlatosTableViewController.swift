//
//  PlatosTableViewController.swift
//  Proyecto-D4
//
//  Created by user183810 on 23/5/21.
//  Copyright © 2021 user183810. All rights reserved.
//

import UIKit
import Alamofire

class PlatosTableViewController: UITableViewController {
    var arrayPlatos = [[String:String]]()
    var paramIdCategoria:String?
    var objDAO = DataBase()
    override func viewDidLoad() {
        super.viewDidLoad()
        print("paramIdC:",paramIdCategoria)
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    override func viewWillAppear(_ animated: Bool) {
        sincronizarPlatos()
        //leerTablaPlatos(idc: paramIdCategoria)
    }
    func leerTablaPlatos(idc:String?)->[[String:String]]{
        return [[String:String]]()
    }
    func sincronizarPlatos(){
        let urlSw = "https://diplomado-restaurant-backend.herokuapp.com/platos"
        Alamofire.request(urlSw, method: .get).responseJSON { (response) in
                   //swift
            if let datoJson  = response.result.value as? [String:Any]{
                  guard   let data = datoJson["data"] as? [[String:Any]] else {return}
                print(data)
                self.objDAO.ejecutarDelete("delete from platos_comidas ")
                //for in de platos, insert
                for objPlato in data {
                     let nombre =  objPlato["nombre"] as? String ?? ""
                     let _id_plat0 = objPlato["_id"] as? String ?? ""
                     let descripcion = objPlato["descripcion"] as? String ?? " "
                    let precio = objPlato["precio"] as? Float ?? 0.0
                     let _id_categoria = objPlato["categoria_id"] as? String ?? ""
                     let archivo = objPlato["imagen"] as? String ?? ""
                 
                     let queryInsert = "INSERT INTO platos_comidas ('id_plato', 'nombre_plato', 'descripcion_plato','precio_plato','archivo_plato','id_categoria','_id_plato') VALUES (null, '\(nombre)', '\(descripcion)','\(precio)','\(archivo)','\(_id_categoria)','\(_id_plat0)');"
                    
                    self.objDAO.ejecutarInsert(queryInsert)
                }
                
                //leer la tabla y asignar al array
                self.arrayPlatos = self.objDAO.ejecutarSelect("select * from platos_comidas") as! [[String:String]]
                //reload del tableView
                self.tableView.reloadData()
            }
        }
    }
}


extension PlatosTableViewController{
    // MARK: - Table view data source

     override func numberOfSections(in tableView: UITableView) -> Int {
         // #warning Incomplete implementation, return the number of sections
         return 1
     }

     override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         // #warning Incomplete implementation, return the number of rows
        return arrayPlatos.count
     }

    
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "platosCell", for: indexPath) as! CustomPlatoTableViewCell
        //recuperar el nombre plato desde el array
        let nombrePlato = arrayPlatos[indexPath.row]["nombre_plato"]
        let precioPlato = arrayPlatos[indexPath.row]["precio_plato"]
        let archivoImg = arrayPlatos[indexPath.row]["archivo_plato"] ?? "avatar"
        
         // Configure the cell...
//         cell.textLabel?.text = nombrePlato
        cell.nombreCell.text = nombrePlato
        cell.precioCell.text = precioPlato
        cell.pintarImagenPlato(nomArchivo: archivoImg)
         return cell
     }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //crear el objDetalle
        let objDetalleTVC = storyboard?.instantiateViewController(identifier: "DetalleId") as! DetalleTableViewController
        //invocar al navigationController para agregar en su flujo usando metodo push
        self.navigationController?.pushViewController(objDetalleTVC, animated: true)
        
    }
    
}
