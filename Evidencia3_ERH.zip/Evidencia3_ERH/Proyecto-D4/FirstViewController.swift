//
//  FirstViewController.swift
//  Proyecto-D4
//
//  Created by user183810 on 23/5/21.
//  Copyright © 2021 user183810. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("viewDidLoad")
    }
    override func viewWillAppear(_ animated: Bool) {
        print("viewWillAppear")
    }
    override func viewDidAppear(_ animated: Bool) {
        print("viewDidAppear")
        animacion()
    }
    
    func animacion(){
         self.logo.frame = CGRect(x: -200, y: 367, width: 204, height: 108)
        UIView.animate(withDuration: 2) {
           
            self.logo.frame = CGRect(x: 105, y: 367, width: 204, height: 108)
        }
        
    }

}

