//
//  LoginViewController.swift
//  Proyecto-D4
//
//  Created by user183810 on 23/5/21.
//  Copyright © 2021 user183810. All rights reserved.
//

import UIKit
import Alamofire

class LoginViewController: UIViewController {

    @IBOutlet weak var txtUser: UITextField!
    
    @IBOutlet weak var txtPass: UITextField!
    
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func procesandoLogin(_ sender: Any) {
        let urlString = "https://diplomado-restaurant-backend.herokuapp.com/auth/clientes-login"
        guard let emailDato = txtUser.text , let passDato = txtPass.text else {
            //usar un alert para indicar que hay un error de algun dato
            return
            
        }
        let parametros = ["email":emailDato,"password":passDato]
        // let parametros = ["email":"cliente@gmail.com","password":"123456"]
        Alamofire.request(urlString, method: .post, parameters: parametros).responseJSON { (respons) in
            if respons.result.isSuccess{
                guard  let jsonRespons = respons.result.value as? [String:Any] else {return}
                guard  let datoResDic = jsonRespons["data"] as? [String:Any] else {return}
                let nombreRes = datoResDic["nombres"] as? String ?? ""
                let tokenRes = datoResDic["token"] as? String ?? ""
                let idCliente = datoResDic["_id"] as? String ?? ""
                print(jsonRespons)
                let datoSesion = ["sesionCli":"1","tokenCli":tokenRes,"_idCli":idCliente,"nombreCli":nombreRes]
                self.defaults.set(datoSesion, forKey: "sesionCliente")
                if tokenRes.count>0 {
                    self.dismiss(animated: true, completion: nil)
                }
            }
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
