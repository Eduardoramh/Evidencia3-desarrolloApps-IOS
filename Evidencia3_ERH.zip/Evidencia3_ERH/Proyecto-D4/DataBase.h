//
//  DataBase.h
//  Diabetes Tips
//
//  Created by user183810 on 23/5/21.
//  Copyright © 2021 user183810. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataBase : NSObject
+(NSString *)getDataBasePath;
+(void) checkAndCreateDatabaseWithName:(NSString* )nameDataBase;
- (NSArray *)ejecutarSelect:(NSString *)select;
- (void)ejecutarInsert:(NSString *)insert;
- (void)ejecutarDelete:(NSString *)deleteString;
- (void)ejecutarUpdate:(NSString *)update;
+ (instancetype)shared;
@property (strong, nonatomic)NSString* dataBaseName;
@end
