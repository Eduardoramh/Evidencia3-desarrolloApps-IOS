//
//  DetalleTableViewController.swift
//  Proyecto-D4
//
//  Created by user183810 on 23/5/21.
//  Copyright © 2021 user183810. All rights reserved.
//

import UIKit

class DetalleTableViewController: UITableViewController {
//    var idPlato = "5b6f341ba45fe600145eb4ea"
    var idPlato = ""
    //1- passing desde lista platos
    //2- select desde tabla platos el objeto plato
    //3- mostrar vista detalle completo
    
    @IBOutlet weak var imagenDetalle: UIImageView!
    
    @IBOutlet weak var nombreDetalle: UILabel!
    
    @IBOutlet weak var precioDetalle: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func agregarPreferido(_ sender: Any) {
    }
    
    @IBAction func agregarCarrito(_ sender: Any) {
        
        
    }
    
   
}
