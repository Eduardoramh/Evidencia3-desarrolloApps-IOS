//
//  CustomPlatoTableViewCell.swift
//  Proyecto-D4
//
//  Created by user183810 on 23/5/21.
//  Copyright © 2021 user183810. All rights reserved.
//

import UIKit

class CustomPlatoTableViewCell: UITableViewCell {

    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var nombreCell: UILabel!
    @IBOutlet weak var descripcionCell: UILabel!
    @IBOutlet weak var precioCell: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        print("celda presenta")
        
        
    }
    func pintarImagenPlato(nomArchivo:String){
        OperationQueue().addOperation {
            let urlImage = "https://diplomado-restaurant-backend.herokuapp.com/images/platos/\(nomArchivo)"
//            let urlImage = "https://diplomado-restaurant-backend.herokuapp.com/images/platos/1534136812516.jpeg"
            guard  let objURLImage = URL(string: urlImage) else {
                print("no hay nombre archivo")
                return}
            do{
                let objDataImage = try Data(contentsOf: objURLImage)
                let imagenCelda = UIImage(data: objDataImage)
                OperationQueue.main.addOperation {
                    self.imageCell.image = imagenCelda
                }
                
                
            }catch{
                print("error en dato imagen:\(urlImage)")
                
            }
            
        }
        
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
