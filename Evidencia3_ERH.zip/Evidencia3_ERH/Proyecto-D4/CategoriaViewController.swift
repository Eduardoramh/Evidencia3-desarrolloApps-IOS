//
//  CategoriaViewController.swift
//  Proyecto-D4
//
//  Created by user183810 on 23/5/21.
//  Copyright © 2021 user183810. All rights reserved.
//

import UIKit
import Alamofire

class CategoriaViewController: UIViewController {
    var arrayCategoria = [[String:String]]()
    let objDAO = DataBase()
    let defaults = UserDefaults.standard
    
    @IBOutlet weak var miTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        presentarLoginVC()
        sincronizarCategorias()
        arrayCategoria = datosCategoria()
        miTableView.reloadData()
    }
    
    func datosCategoria()->[[String:String]]{
       return DataBase().ejecutarSelect("select * from categoria_platos") as! [[String:String]]
        
    }
    func presentarLoginVC(){
//        si hay sesion retorna

        if evaluaSesion(){
            return
        }else{
            //presentar al modal VC login
            let objLogin = storyboard?.instantiateViewController(identifier: "loginVCId") as! LoginViewController
            present(objLogin, animated: true, completion: nil)
//            navigationController?.pushViewController(objLogin, animated: true)
        }
    }
    func evaluaSesion()->Bool{
        // evaluar si tenemos el token
        //        let datoSesion = ["sesionCli":"1","tokenCli":tokenRes,"_idCli":idCliente,"nombreCli":nombreRes]
//        var success = false
//        let sesionMenu = defaults.object(forKey: "sesionCliente") as! [String:String]
//        let tokenCli = sesionMenu["tokenCli"] as? String ?? ""
//        if tokenCli.count > 0 {
//            success = true
//        }else{
//            success = false
//        }
//        return success
         return true
    }
    
    func sincronizarCategorias(){
        
        let urlSW = "https://diplomado-restaurant-backend.herokuapp.com/categorias"
        //metodo GET
        //parametros no
        //token no
        Alamofire.request(urlSW, method: .get).responseJSON { (response) in
            //swift
            if let datoJson  = response.result.value as? [String:Any]{
                guard   let data = datoJson["data"] as? [[String:Any]] else {return}
                //0- borrar la tabla
                self.objDAO.ejecutarDelete("delete from categoria_platos")
                //1-recorrer el array de datos "data" e insertar al tabla de categorias
                for objDato in data {
                    //2-recoperar campo nombre e _id
                    let nombreCategoria = objDato["nombre"] as? String ?? "error nombre"
                    let _idCategoria =  objDato["_id"] as? String ?? "error _id"
                    
                    //3-insert a la tabla categoria
                    let queryInsert = "INSERT INTO categoria_platos ('id_categoria', 'nombre_categoria', '_id_categoria') VALUES (null, '\(nombreCategoria)', '\(_idCategoria)');"
                    self.objDAO.ejecutarInsert(queryInsert)
                    
                    
                }
                //4- leer la tabla y asingar al arrayCategoria
                
                //5- reload al tableView
                   
                
                
            }
        
            }
    }
    
    @IBAction func cerrandoSesion(_ sender: Any) {
        let objVacio = [String:String]()
        defaults.set(objVacio, forKey:"sesionCliente")
        viewWillAppear(false)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension CategoriaViewController:UITableViewDelegate,UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayCategoria.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaCategoria", for: indexPath)
        //recuperar los nombres de categoria
        let nombreCategoria =  arrayCategoria[indexPath.row]["nombre_categoria"]
//        celda.textLabel?.text = "fila prueba"
        celda.textLabel?.text = nombreCategoria
        return celda
    }
    
}
